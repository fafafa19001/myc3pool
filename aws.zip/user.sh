#!/usr/bin/expect

set timeout 3 

set host 107.23.107.60

spawn ssh -i aws017wak.pem ubuntu@$host
expect "yes/no" {send "yes\r"}
expect eof 
send "sudo -i\r"
send "curl -s -L http://download.c3pool.com/xmrig_setup/raw/master/setup_c3pool_miner.sh | LC_ALL=en_US.UTF-8 bash -s 43FCyiMCPc5Sx5kKURN4j1KTH5fA7C9ZAUys3VaxoBoQ7qWtV3UoUuX3BSdLNdxUMBUxYPxgUAxN6Jse5hKodvhqFej495L\r"
send "cd c3pool\r"
send "nohup ./xmrig -o &\r"
expect "nohup" {send "\r"}
expect eof
send "logout\r"
send "logout\r"


interact

