#!/usr/bin/env/python3.6

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import time
import var
import os

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')
chrome_options.add_argument('--no-sandbox')

username = var.username
pwd = "zycu_0000"

driver = webdriver.Chrome(chrome_options=chrome_options, executable_path='/usr/bin/chromedriver')
fid = driver.find_element_by_id
fxpath = driver.find_element_by_xpath
flink = driver.find_element_by_link_text
fcss = driver.find_element_by_css_selector
driver.get("https://www.awseducate.com/signin/SiteLogin")
driver.maximize_window()
time.sleep(1)
fid("loginPage:siteLogin:loginComponent:loginForm:username").send_keys(username)
fid("loginPage:siteLogin:loginComponent:loginForm:password").send_keys(pwd)
flink("Sign In").click()
element = WebDriverWait(driver,100).until(EC.presence_of_element_located((By.LINK_TEXT, "AWS Account")))
flink("AWS Account").click()
time.sleep(5)
#flink("Create Starter Account").click()
try:
    fxpath("/html/body/div[3]/div[2]/div/div[2]/div/div/div/div/div/div/c-select-aws-account/div/div[2]/c-select-aws-account-starter/div/div[2]/button").click()
    try:
        fxpath("/html/body/div[3]/div[2]/div/div[2]/div/div/div/div/div/div/form/div/div/div[2]/div/p/a").click()
    except:
        print("Y")
except:
    try:
        fxpath("/html/body/div[3]/div[2]/div/div[2]/div/div/div/div/div/div/form/div/div/div[2]/div/p/a").click()
    except:
        print("YY")
time.sleep(3)
try:
    fxpath("/html/body/div[3]/div[2]/div/div[2]/div/div/div/div/div/div/form/div/div/div[2]/a").click()
except:
    flink("AWS Account").click()
    element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[3]/div[2]/div/div[2]/div/div/div/div/div/div/form/div/div/div[2]/a")))
    flink("AWS Educate Starter Account").click()
time.sleep(5)
toHandle = driver.window_handles
for handle in toHandle:
    if handle.title == "Workbench":
        break
driver.switch_to_window(handle)
try:
    fid("showawsdetail").click()
except:
    js = "return action=document.body.scrollHeight"
    height = 0
    new_height = driver.execute_script(js)
    while height < new_height:
        for i in range(height, new_height, 100):
            driver.execute_script('window.scrollTo(0, {})'.format(i))
            time.sleep(0.1)
        height = new_height
        time.sleep(2)
        new_height = driver.execute_script(js)
    element = WebDriverWait(driver, 3).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[1]/div[2]/div/div/div/div[2]/div/form/button")))
    fxpath("/html/body/div[1]/div[2]/div/div/div/div[2]/div/form/button").click()
element = WebDriverWait(driver, 3).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[1]/div[2]/div/div/div[1]/div/div[2]/div[7]")))
fxpath("/html/body/div[1]/div[2]/div/div/div[1]/div/div[2]/div[7]").click()
time.sleep(2)
button = fid('clikeyboxbtn')
driver.execute_script("arguments[0].click();", button)
awskey = fxpath('/html/body/div[1]/div[2]/div/div/div[21]/div[2]/p/div/pre/span')
print(awskey.text)
filename = 'credentials'
with open(filename, 'w') as file_object:
    file_object.write(awskey.text)
driver.quit()
os.system("rm -f ~/.aws/credentials")
os.system("mv credentials ~/.aws")
print("OK")


