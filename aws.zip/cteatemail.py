from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
import time

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')
chrome_options.add_argument('--no-sandbox')

username = "fafafa19002@yandex.ru"
pwd = "3868185820"

driver = webdriver.Chrome(chrome_options=chrome_options, executable_path='/usr/bin/chromedriver')

fid = driver.find_element_by_id
fxpath = driver.find_element_by_xpath
flink = driver.find_element_by_link_text
fcss = driver.find_element_by_css_selector
driver.get("https://connect.yandex.com/portal/admin/users/1130000045562252")
driver.maximize_window()
time.sleep(1)
element = WebDriverWait(driver,100).until(EC.presence_of_element_located((By.ID, "passp-field-login")))
fid("passp-field-login").send_keys(username)
fxpath("//button[contains(@class,'Button2_type_submit')]").click()
element = WebDriverWait(driver,100).until(EC.presence_of_element_located((By.XPATH, "//input[@name='passwd']")))
fxpath("//input[@name='passwd']").send_keys(pwd)

element = fxpath("//button[contains(@class,'Button2_view_action')]")
driver.execute_script("arguments[0].click();", element)
#fxpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div[3]/div/div/form/div[2]/div/span/input").send_keys(pwd)
#fxpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div[3]/div/div/form/div[3]/button").click()
element = WebDriverWait(driver,100).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[1]/div/div[2]/div[1]/div/div/div/div[1]/div[1]/a")))
fxpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div/div[1]/div[1]/a").click()
time.sleep(3)

count = 1
num = 245
numm = 1001
while num < numm:
    if len(str(num)) == 1:
        numstr = "00"+str(num)
    elif len(str(num)) == 2:
        numstr = "0"+str(num)
    else:
        numstr = str(num)
    element = WebDriverWait(driver,100).until(EC.presence_of_element_located((By.CLASS_NAME, "ui-flat-button__width_available")))
    add = driver.find_element_by_class_name("ui-flat-button__width_available") 
    driver.execute_script("arguments[0].click();", add)
    time.sleep(0.5)
    #add a person
    fxpath("/html/body/div[contains(@class, 'popup_direction_top-center')]/div/div/div[1]/div[1]").click()
    #new = driver.find_element_by_class_name("modal-box")
    element = WebDriverWait(driver,100).until(EC.presence_of_element_located((By.XPATH, "//button[contains(@class,'button2_type_submit')]")))
    fxpath("//input[@name='name[last][ru]']").send_keys("aws")
    fxpath("//input[@name='name[first][ru]']").send_keys(numstr)
    fxpath("//input[contains(@name,'nickname__')]").send_keys("aws"+numstr)
    fxpath("//input[contains(@name,'password__')]").send_keys("3868185820")
    fxpath("//input[contains(@name,'password_confirmation__')]").send_keys("3868185820")
    time.sleep(0.5)
    fxpath("//button[contains(@class,'button2_type_submit')]").click()
    element = WebDriverWait(driver,100).until_not(EC.presence_of_element_located((By.XPATH, "//button[contains(@class,'button2_type_submit')]")))

    count = count + 1
    print("aws"+numstr)
    num=num+1
print("\n\n一共创建"+str(count)+"个邮箱\n\n")
