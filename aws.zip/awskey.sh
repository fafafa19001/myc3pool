#!usr/bin/expect

send "rm -f ~/.aws/credentials\r"
send "mv credentials ~/.aws\r"
send "python3.6 createins.py\r"
send "python3.6 list_instances.py\r"
send "expect user.sh\r"
