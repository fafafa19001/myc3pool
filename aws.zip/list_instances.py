#!/usr/bin/env python3.6

import boto3
import var
import subprocess
import os
import createins
import time

time.sleep(30)
ec2 = boto3.resource('ec2')
hostips = []
for instance in ec2.instances.all():
    hostips.append(instance.public_ip_address)
for sec in ec2.security_groups.all():
    print(sec.id)
os.system("chmod 400 "+var.keypairname+".pem")
filename = 'user.sh'
for hostip in hostips: 
    usersh = []
    with open(filename, 'r') as f1:
        for line in f1.readlines():
            if "set host" in line:
                line = "set host " + hostips[3] +"\n"
                print("it")
            elif "spawn ssh -i" in line:
                line = "spawn ssh -i " + var.keypairname +".pem ubuntu@$host\n"
            usersh.append(line)
    with open(filename, 'w') as f2:
        for line in usersh:
            f2.write(line)
    val = os.system("expect user.sh")
    print(val)



