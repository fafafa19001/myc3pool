#!/usr/bin/env python3.6

import boto3
import var
import aws
import time

ec2 = boto3.client('ec2')
ec2r = boto3.resource('ec2')

keypairs = []
for key in ec2r.key_pairs.all():
    keypairs.append(key)
if len(keypairs) == 0:
    keypair = ec2.create_key_pair(KeyName = var.keypairname,)
    rsa = keypair['KeyMaterial']
    filename = keypair['KeyName']+'.pem'
    with open(filename, 'w') as file_object:
        file_object.write(rsa)
    keyname = keypair['KeyName']
else:
    keypair = ec2r.KeyPair(var.keypairname)
    keyname = keypair.key_name
imageid='ami-0dba2cb6798deb6d8'
instancetype='t2.2xlarge'
for sec in ec2r.security_groups.all():
    print(sec.id)
if len(sec.ip_permissions) <= 1:
    response = ec2.authorize_security_group_ingress(
        GroupId=sec.id,
        IpPermissions=[
            {
                'FromPort': 22,
                'IpProtocol': 'tcp',
                'IpRanges': [
                    {
                        'CidrIp': '0.0.0.0/0',
                        'Description': 'RDP access from the NY office',
                    },
                ],
                'ToPort': 22,
            },
        ],
    )
time.sleep(5)
instance = ec2r.create_instances(ImageId=imageid,MinCount=1,MaxCount=4,KeyName=keyname, InstanceType=instancetype)
